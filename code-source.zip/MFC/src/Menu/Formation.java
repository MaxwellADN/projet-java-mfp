package Menu;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JTabbedPane;
import javax.swing.border.EtchedBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import java.awt.SystemColor;
import java.awt.Color;

import javax.swing.JButton;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.AbstractListModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.LineBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;

public class Formation extends JFrame {

	private JPanel contentPane;
	public JTable table;
	private JTextField textField;
	private DefaultTableModel model;
	private TableColumn col2;
	private TableColumn col;
	protected int row;
	protected int row1;
	private TableColumn col1;
	private boolean bool;
	public String rs;
	private JTextField textField_code;
	private JTextField textField_nom;
	private JTextField textField_Ddebut;
	private JTextField textField_Dfin;
	private JTextField textField_duree;
	private JTextField textField_prix;
	
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Formation frame = new Formation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Formation() {
		setBackground(SystemColor.inactiveCaption);
		setTitle("Liste Des Formations MFP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 50, 1085, 663);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.controlDkShadow);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, new Color(0, 0, 0)));
		panel.setBounds(0, 0, 199, 613);
		contentPane.add(panel);
		
		// bouton cr�er une nouvelle formation------------------------------------------------------------------------
		JButton btnNewButton = new JButton("Nouvelle Formation");
		btnNewButton.setBounds(0, 24, 199, 39);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AjoutFormation fenetre = new AjoutFormation();
				fenetre.setVisible(true);
			}
		});
		panel.setLayout(null);
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(btnNewButton);
		
		// fin creer------------------------------------------------------------------------------------------------------
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.controlDkShadow);
		panel_1.setBounds(0, 150, 189, 421);
		panel.add(panel_1);
		panel_1.setLayout(null);
		panel_1.setVisible(false);// cacher le formulaire 
		
		// Bouton Modifier ---- D�but ---------------------------------------
		JButton btnNewButton_1 = new JButton("Modifier \r\n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_1.setVisible(true);// aficher le formulaire
				row =table.getSelectedRow();
				rs = table.getValueAt(row, 0).toString();// recuperation nom de formation
								
				try {
					
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					ResultSet select = state.executeQuery("SELECT * FROM formation WHERE NOMFORMATION = '"+rs+"'");
					while (select.next()){
					String code = select.getString("CODEFORMATION");
					String nom = select.getString("NOMFORMATION");
					String DateDebut = select.getString("DATEDEBUTFORMATION");
					String DateFin = select.getString("DATEFINFORMATION");
					String duree = select.getString("DUREE");
					String prix = select.getString("PRIXFORMATION");
					
					textField_code.setText(code);
					textField_nom.setText(nom);
					textField_Ddebut.setText(DateDebut);
					textField_Dfin.setText(DateFin);
					textField_duree.setText(duree);
					textField_prix.setText(prix);
					
					}
					
					
				
										 
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				
			}
		});
		btnNewButton_1.setBounds(0, 63, 199, 38);
		btnNewButton_1.setBackground(SystemColor.activeCaption);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(btnNewButton_1);
		
		// bouton Modifier ------Fin --------------------------------------------------------------------------------------------
		
		
		// bouton supprimer ------------- debut -------------------------------------------------------------------------------
		JButton btnNewButton_2 = new JButton("Supprimer\r\n");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row = table.getSelectedRow();// selection ligne
				rs = table.getValueAt(row, 0).toString();// recuperation nom de formation
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					java.sql.PreparedStatement supprimer =  connection.prepareStatement("DELETE FROM formation WHERE NOMFORMATION= '"+rs+"'");
					supprimer.executeUpdate();
					
					JOptionPane.showMessageDialog(panel, "Les donn�es ont �t� supprim�");
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				// recharcher table-----------------------------------------------------------------------------------------------
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECT NOMFORMATION, DATEDEBUTFORMATION, DATEFINFORMATION, DUREE, PRIXFORMATION  FROM formation");){
							
							while(resultset.next()){							
								table.setModel(DbUtils.resultSetToTableModel(resultset));	
							}
							
							
							resultset.close();
					}
					
					catch(SQLException sqle){
						sqle.printStackTrace();
					}
				// fin recharger--------------------------------------------------------------------------------------------------
				
			}
		});
		btnNewButton_2.setBounds(0, 100, 199, 39);
		btnNewButton_2.setBackground(SystemColor.activeCaption);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(btnNewButton_2);
		// fin bouton supprimer-------------------------------------------------------------------------------------------------------------
		
		textField = new JTextField();
		textField.setBounds(0, 0, 174, 25);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setBackground(SystemColor.menu);
		btnNewButton_3.setIcon(new ImageIcon(Formation.class.getResource("/images/icone_search.png")));
		btnNewButton_3.setBounds(170, 0, 29, 25);
		panel.add(btnNewButton_3);
		
		JButton btnRetour = new JButton("Retour");// methode Bouton retour de la fenetre formation 
		btnRetour.setBackground(SystemColor.activeCaption);
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FenMenuPrincipal fenetre = new FenMenuPrincipal();
				fenetre.setVisible(true);
				setVisible(false);
			}
		});
		btnRetour.setBounds(0, 579, 199, 23);
		panel.add(btnRetour);
		
	
		
		JLabel label = new JLabel("Code Formation   :");
		label.setFont(new Font("Arial Black", Font.PLAIN, 12));
		label.setBounds(10, 36, 124, 27);
		panel_1.add(label);
		
		textField_code = new JTextField();
		textField_code.setColumns(10);
		textField_code.setBounds(10, 60, 178, 22);
		panel_1.add(textField_code);
		
		JLabel label_1 = new JLabel("Nom Formation   :");
		label_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		label_1.setBounds(10, 93, 124, 27);
		panel_1.add(label_1);
		
		textField_nom = new JTextField();
		textField_nom.setColumns(10);
		textField_nom.setBounds(10, 118, 178, 22);
		panel_1.add(textField_nom);
		
		JLabel lblDateDebut = new JLabel("Date debut  :");
		lblDateDebut.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDateDebut.setBounds(10, 151, 124, 27);
		panel_1.add(lblDateDebut);
		
		textField_Ddebut = new JTextField();
		textField_Ddebut.setColumns(10);
		textField_Ddebut.setBounds(10, 178, 178, 22);
		panel_1.add(textField_Ddebut);
		
		JLabel lblDateFin = new JLabel("Date fin  :");
		lblDateFin.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDateFin.setBounds(10, 211, 124, 27);
		panel_1.add(lblDateFin);
		
		textField_Dfin = new JTextField();
		textField_Dfin.setColumns(10);
		textField_Dfin.setBounds(10, 240, 178, 22);
		panel_1.add(textField_Dfin);
		
		JLabel lblDure = new JLabel("Dur\u00E9e  :");
		lblDure.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDure.setBounds(10, 273, 124, 22);
		panel_1.add(lblDure);
		
		textField_duree = new JTextField();
		textField_duree.setColumns(10);
		textField_duree.setBounds(10, 297, 178, 22);
		panel_1.add(textField_duree);
		
		JLabel lblPrix = new JLabel("Prix : ");
		lblPrix.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblPrix.setBounds(10, 332, 124, 22);
		panel_1.add(lblPrix);
		
		textField_prix = new JTextField();
		textField_prix.setColumns(10);
		textField_prix.setBounds(10, 354, 178, 22);
		panel_1.add(textField_prix);
		
		// CREATION ET AFFICHAGE DE LA JTABLE--------------------------------
		
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(209, 11, 850, 602);
				contentPane.add(scrollPane);
				
				
				table = new JTable();
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				final Color alternateColor=new Color(242,242,242);
		        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer()
		        {//alternate background 
		                    @Override
		                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
		                            boolean hasFocus, int row, int column)
		                        {
		                            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		                            if ( !isSelected )
		                                c.setBackground(row % 2 == 0 ? Color.white : alternateColor);
		                            return c;
		                        };
		                });
		              
				table.setFont(new Font("Arial", Font.BOLD, 12));
				scrollPane.setViewportView(table);
				
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECT NOMFORMATION, DATEDEBUTFORMATION, DATEFINFORMATION, DUREE, PRIXFORMATION  FROM formation");){
							
							while(resultset.next()){							
								table.setModel(DbUtils.resultSetToTableModel(resultset));
								table.setAutoCreateColumnsFromModel(false);
								col= table.getColumnModel().getColumn(2);
							    col2= table.getColumnModel().getColumn(0);
							    col1= table.getColumnModel().getColumn(1);
							    col2.setPreferredWidth(380);
							    col.setPreferredWidth(100);
							    col1.setPreferredWidth(100);
							}	
							
							resultset.close();
					}
					
					catch(SQLException sqle){
						sqle.printStackTrace();
					}
				
				
				
				// fin Jtable 
				
		
		// Bouton Ok ----engistrer modifications-------------------------------------------------
		JButton btnEnregistrer = new JButton("");
		btnEnregistrer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean bool= false;
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					
					String code= textField_code.getText();
					String nom= textField_nom.getText();
					String DateDebut= textField_Ddebut.getText();
					String DateFin= textField_Dfin.getText();
					String duree= textField_duree.getText();
					String prix= textField_prix.getText();
					java.sql.PreparedStatement modifier =  connection.prepareStatement("UPDATE `mfc`.`formation`"
							+ " SET `CODEFORMATION` = '"+code+"', `NOMFORMATION` = '"+nom+"',"
							+ " `DATEDEBUTFORMATION` = '"+DateDebut+"', `DATEFINFORMATION` = '"+DateFin+"',"
							+ "`DUREE` = '"+duree+"', `PRIXFORMATION` = '"+prix+"' WHERE `formation`.`NOMFORMATION` = '"+rs+"';");
					modifier.executeUpdate();
					modifier.close();
					bool =true;	
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				bool = false;
				}
				
				if (bool=true){
				panel_1.setVisible(false);
				JOptionPane.showMessageDialog(panel_1, "Les donn�es ont �t� bien enregistrer");
				}
				
				
				// recharcher table-----------------------------------------------------------------------------------------------
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECT NOMFORMATION, DATEDEBUTFORMATION, DATEFINFORMATION, DUREE, PRIXFORMATION  FROM formation");){
							
							while(resultset.next()){							
								table.setModel(DbUtils.resultSetToTableModel(resultset));	
							}
							
							
							resultset.close();
					}
					
					catch(SQLException sqle){
						
						sqle.printStackTrace();
					}
				// fin recharger--------------------------------------------------------------------------------------------------
				
			}
		});
		btnEnregistrer.setBackground(SystemColor.controlDkShadow);
		btnEnregistrer.setIcon(new ImageIcon(Formation.class.getResource("/images2/ok.png")));
		btnEnregistrer.setBounds(10, 387, 40, 23);
		panel_1.add(btnEnregistrer);
		
		JButton btnAnnuler = new JButton("");
		btnAnnuler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel_1.setVisible(false);
			}
		});
		btnAnnuler.setIcon(new ImageIcon(Formation.class.getResource("/images2/annuler.png")));
		btnAnnuler.setBackground(SystemColor.controlDkShadow);
		btnAnnuler.setBounds(149, 387, 40, 23);
		panel_1.add(btnAnnuler);
		
		JLabel label_2 = new JLabel("Modifier Formation");
		label_2.setFont(new Font("Arial Black", Font.BOLD, 14));
		label_2.setBounds(10, 0, 186, 36);
		panel_1.add(label_2);
		
		
	}
}
