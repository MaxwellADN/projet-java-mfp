package Menu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.UIManager;

public class FenMenuPrincipal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenMenuPrincipal frame = new FenMenuPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FenMenuPrincipal() {
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 90, 689, 399);
		contentPane = new JPanel();
		contentPane.setForeground(SystemColor.controlShadow);
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JButton JButton_formation = new JButton("FORMATION");
		JButton_formation.setFont(new Font("Arial Black", Font.PLAIN, 12));
		JButton_formation.setBackground(SystemColor.activeCaption);
		JButton_formation.setBounds(0, 82, 229, 130);
		JButton_formation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Formation fenetre = new Formation();
				fenetre.setVisible(true);
				setVisible(false);
			}
		});
		contentPane.setLayout(null);
		JButton_formation
				.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/formation.png")));
		contentPane.add(JButton_formation);

		JButton JButton_inscription = new JButton("INSCRIPTION");
		JButton_inscription.setFont(new Font("Arial Black", Font.PLAIN, 12));
		JButton_inscription.setBackground(SystemColor.activeCaption);
		JButton_inscription.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/ajouter.png")));
		JButton_inscription.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inscription fenetre = new Inscription();
				fenetre.setVisible(true);
				setVisible(false);
			}
		});
		JButton_inscription.setBounds(229, 82, 229, 130);
		contentPane.add(JButton_inscription);

		JButton JButton_session = new JButton("SESSION FORMATION");
		JButton_session.setFont(new Font("Arial Black", Font.PLAIN, 11));
		JButton_session.setBackground(SystemColor.activeCaption);
		JButton_session.setBounds(0, 210, 229, 130);
		JButton_session.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/calandrier.png")));
		JButton_session
				.setSelectedIcon(new ImageIcon(
						"C:\\Users\\C\u00E9lia\\workspace\\MFC_Java\\images\\Session.png")); 
		JButton_session.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SessionFormation session = new SessionFormation();
				session.setVisible(true);
				setVisible(false);
			}
		});
		contentPane.add(JButton_session);

		JButton JButton_stagiaire = new JButton("STAGIAIRE");
		JButton_stagiaire.setFont(new Font("Arial Black", Font.PLAIN, 12));
		JButton_stagiaire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Stagiaire fenetre = new Stagiaire();
				fenetre.setVisible(true);
				setVisible(false);
				
			}
		});
		JButton_stagiaire.setBackground(SystemColor.activeCaption);
		JButton_stagiaire.setBounds(229, 210, 229, 130);
		JButton_stagiaire.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images/Stagiaire.png")));
		contentPane.add(JButton_stagiaire);
		
		JButton btnDeconnecter = new JButton("Deconnection");
		btnDeconnecter.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/deconnecter-gtk-icone-5087-32.png")));
		btnDeconnecter.setBackground(SystemColor.activeCaption);
		btnDeconnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FenConnexion fenetre = new FenConnexion();
				fenetre.setVisible(true);
				setVisible(false);
				}
		});
		btnDeconnecter.setBounds(456, 210, 218, 130);
		contentPane.add(btnDeconnecter);
		
		JButton btnNewButton = new JButton("CONSULTANT ");
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Consultant fenetre = new Consultant();
				fenetre.setVisible(true);
			}
		});
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/garcon.png")));
		btnNewButton.setBounds(456, 82, 218, 130);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(0, 0, 673, 87);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(FenMenuPrincipal.class.getResource("/images2/LogoMfc.PNG")));
		label.setBounds(169, 11, 336, 76);
		panel.add(label);
		
		JLabel lblCopyright = new JLabel("Copyright 2015-2016 Consulting SIO");
		lblCopyright.setForeground(SystemColor.desktop);
		lblCopyright.setBounds(239, 342, 189, 21);
		contentPane.add(lblCopyright);
	}
}
