package Menu;

import java.sql.*;

public class DbConnector {
	
	public static Connection connectDB() throws SQLException{
		
		String url = "jdbc:mysql://127.0.0.1:3306/";
  		String database = "mfc?zeroDateTimeBehavior=convertToNull";
	  	String userName = "root"; 
	  	String password = "";
	  	
		return DriverManager.getConnection(url + database, userName, password); 
		
		
	}

}
