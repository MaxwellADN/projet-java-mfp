package Menu;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JTabbedPane;
import javax.swing.border.EtchedBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import java.awt.SystemColor;
import java.awt.Color;

import javax.swing.JButton;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.AbstractListModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;

public class Inscription extends JFrame {

	private JPanel contentPane;
	public JTable table;
	private JTextField textField;
	private DefaultTableModel model;
	private TableColumn col2;
	private TableColumn col;
	protected int row;
	protected int row1;
	private TableColumn col1;
	private boolean bool;
	public String rs;
	
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inscription frame = new Inscription();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inscription() {
		setTitle("Liste Des Inscriptions MFP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 50, 1085, 663);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.controlDkShadow);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, new Color(0, 0, 0)));
		panel.setBounds(0, 0, 199, 613);
		contentPane.add(panel);
		
		//creer une indcritpion -----------------------------------------------------------------------------------------------
		JButton btnNewButton = new JButton("Cr�er Une Inscription");
		btnNewButton.setBounds(0, 24, 199, 39);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AjoutInscription fenetre = new AjoutInscription();
				fenetre.setVisible(true);
			}
		});
		panel.setLayout(null);
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(btnNewButton);
		// fin-------------------------------------------------------------------------------------------------------------------
	
		
		//bouton supprimer ---------------------------------------------------------------------------------------------------
		JButton btnNewButton_2 = new JButton("Supprimer\r\n");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = table.getSelectedRow();// selection ligne
				rs = table.getValueAt(row, 2).toString();// recuperation date
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					java.sql.PreparedStatement supprimer =  connection.prepareStatement("DELETE FROM inscription WHERE DATEINSCRIPTION = '"+rs+"'");
					supprimer.executeUpdate();
					supprimer.close();
					JOptionPane.showMessageDialog(panel, "Les donn�es ont �t� supprim�");
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				
				// recharcher table-----------------------------------------------------------------------------------------------
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECTSELECT NOMSTAGIAIRE, PRENOMSTAGIAIRE, DATEINSCRIPTION FROM stagiaire S, inscription I"
								+ " WHERE S.MATRICULESTAGIAIRE = I.MATRICULESTAGIAIRE");){
							
							while(resultset.next()){							
								table.setModel(DbUtils.resultSetToTableModel(resultset));	
							}
							
							
							resultset.close();
					}
					
					catch(SQLException sqle){
						sqle.printStackTrace();
					}
				// fin recharger--------------------------------------------------------------------------------------------------
				
			}
		});
		btnNewButton_2.setBounds(0, 62, 199, 39);
		btnNewButton_2.setBackground(SystemColor.activeCaption);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(btnNewButton_2);
		
		//  fin bouton supprimer ----------------------------------------------------------------------------------------------------
		
		textField = new JTextField();
		textField.setBounds(0, 0, 174, 25);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setBackground(SystemColor.menu);
		btnNewButton_3.setIcon(new ImageIcon(Inscription.class.getResource("/images/icone_search.png")));
		btnNewButton_3.setBounds(170, 0, 29, 25);
		panel.add(btnNewButton_3);
		
		JButton btnRetour = new JButton("Retour");// methode Bouton retour de la fenetre formation 
		btnRetour.setBackground(SystemColor.activeCaption);
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FenMenuPrincipal fenetre = new FenMenuPrincipal();
				fenetre.setVisible(true);
				setVisible(false);
			}
		});
		btnRetour.setBounds(0, 579, 199, 23);
		panel.add(btnRetour);
		
		// CREATION ET AFFICHAGE DE LA JTABLE--------------------------------
		
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(209, 11, 850, 602);
				contentPane.add(scrollPane);
				
				
				table = new JTable();
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				final Color alternateColor=new Color(242,242,242);
		        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer()
		        {//alternate background 
		                    @Override
		                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
		                            boolean hasFocus, int row, int column)
		                        {
		                            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		                            if ( !isSelected )
		                                c.setBackground(row % 2 == 0 ? Color.white : alternateColor);
		                            return c;
		                        };
		                });
		              
				table.setFont(new Font("Arial", Font.BOLD, 12));
				scrollPane.setViewportView(table);
				
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECT NOMSTAGIAIRE, PRENOMSTAGIAIRE, DATEINSCRIPTION FROM stagiaire S, inscription I"
								+ " WHERE S.MATRICULESTAGIAIRE = I.MATRICULESTAGIAIRE ");){
							
							while(resultset.next()){							
								table.setModel(DbUtils.resultSetToTableModel(resultset));
								table.setAutoCreateColumnsFromModel(false);
								col= table.getColumnModel().getColumn(2);
							    col2= table.getColumnModel().getColumn(0);
							    col1= table.getColumnModel().getColumn(1);
							    col2.setPreferredWidth(380);
							    col.setPreferredWidth(100);
							    col1.setPreferredWidth(100);
							}				
					}
					
					catch(SQLException sqle){
						sqle.printStackTrace();
					}
		
		
	}
}
