package Menu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;

import com.mysql.jdbc.ResultSetMetaData;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;

import javax.swing.UIManager;

import java.awt.Font;
import java.awt.Window.Type;
import java.awt.SystemColor;
import java.awt.Dialog.ModalExclusionType;

import javax.swing.border.LineBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;

public class FenConnexion extends JFrame {

	private JPanel contentPane;
	private JTextField JText_user;
	private JPasswordField textField_pass;
	Connexion connect = new Connexion();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenConnexion frame = new FenConnexion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FenConnexion() {
		setResizable(false);
		setTitle("Authentification");
		setForeground(Color.DARK_GRAY);
		setFont(new Font("Arial", Font.BOLD, 13));
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 200, 450, 336);
		contentPane = new JPanel();
		contentPane.setForeground(Color.DARK_GRAY);
		contentPane.setToolTipText("");
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(104, 11, 235, 14);
		lblNewLabel.setForeground(Color.RED);
		
		
		JButton JButton_Valider = new JButton("Valider");
		JButton_Valider.setBounds(90, 248, 121, 23);
		JButton_Valider.setFont(new Font("Arial", Font.BOLD, 12));
		JButton_Valider.setBackground(SystemColor.activeCaption);
		JButton_Valider.addActionListener(new ActionListener() {// action sur bouton valider
			public void actionPerformed(ActionEvent arg0) {
								
				try(Connection connection = DbConnector.connectDB();// connection a la base de donn�es 
					Statement state= connection.createStatement();
					ResultSet resultset = state.executeQuery("SELECT * FROM user");){//realisation de la requete sql simple 
						while(resultset.next()){
							int[] Id = {resultset.getInt("IdUser")};// id recuperer dans un tableau
							String pseudo = resultset.getString("Pseudo");
							String mdp = resultset.getString("Pass");
							
							for (int id: Id)// pour chaque ID 
							if (JText_user.getText().equals(pseudo) && textField_pass.getText().equals(mdp)){
								FenMenuPrincipal fenetre = new FenMenuPrincipal();
								fenetre.setVisible(true);
								setVisible(false);
							}
							
							else{ 
																
								lblNewLabel.setText("Identifiants incorrect \n veillez r�essayer");	
							}
				}
						
				}
				catch(SQLException sqle){
					sqle.printStackTrace();
				}
				
			}
		});

		JText_user = new JTextField();
		JText_user.setBounds(183, 117, 208, 20);
		JText_user.setColumns(10);

		textField_pass = new JPasswordField();
		textField_pass.setBounds(183, 171, 208, 20);
		textField_pass.setColumns(10);

		JLabel JLabel_user = new JLabel("Nom utilisateur :");
		JLabel_user.setBounds(52, 119, 121, 14);
		JLabel_user.setFont(new Font("Arial", Font.PLAIN, 14));
		JLabel_user.setForeground(new Color(0, 0, 0));

		JLabel JLabel_MDP = new JLabel("Mot de passe  :");
		JLabel_MDP.setBounds(52, 173, 121, 14);
		JLabel_MDP.setFont(new Font("Arial", Font.PLAIN, 14));
		JLabel_MDP.setForeground(new Color(0, 0, 0));

		JButton JButton_cancel = new JButton("Quitter");// bouton quitter
		JButton_cancel.setBounds(242, 248, 121, 23);
		JButton_cancel.setFont(new Font("Arial", Font.BOLD, 12));
		JButton_cancel.setBackground(SystemColor.activeCaption);
		JButton_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});

		JLabel lblConnectezVous = new JLabel("Connexion");
		lblConnectezVous.setBounds(63, 43, 148, 34);
		lblConnectezVous.setForeground(new Color(0, 0, 0));
		lblConnectezVous.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblConnectezVous.setBackground(Color.DARK_GRAY);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(JButton_Valider);
		contentPane.add(JText_user);
		contentPane.add(textField_pass);
		contentPane.add(JLabel_user);
		contentPane.add(JLabel_MDP);
		contentPane.add(JButton_cancel);
		contentPane.add(lblConnectezVous);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(153, 180, 209), 3));
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(46, 78, 357, 151);
		contentPane.add(panel);
		
	}

	public static JFrame getTopLevelAncestor() {
		// TODO Auto-generated method stub
		return null;
	}
}
