package Menu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.SystemColor;

public class AjoutInscription extends JFrame {

	protected static final int Null = 0;
	private JPanel contentPane;
	private JTextField textField_nom;
	private JTextField textField_matricule;
	private JTextField textField_prenom;
	private JTextField textField_tel;
	private JTextField textField_mail;
	private JTextField textField_adresse;
	private int rs;
	private int matricule;
	private JTextField textField_date;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AjoutInscription frame = new AjoutInscription();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AjoutInscription() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 481);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNouvelleStagiaire = new JLabel("Inscription Stagiaire");
		lblNouvelleStagiaire.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNouvelleStagiaire.setBounds(31, 28, 186, 36);
		contentPane.add(lblNouvelleStagiaire);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(31, 65, 350, 332);
		contentPane.add(panel);
		panel.setLayout(null);
		
	
		
		JLabel lblNom = new JLabel("Nom   :");
		lblNom.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNom.setBounds(10, 22, 124, 36);
		panel.add(lblNom);
		
		JLabel lblNewLabel = new JLabel("Prenom         :");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 69, 124, 36);
		panel.add(lblNewLabel);
		
		JLabel lblTel = new JLabel("T�l�phone       :");
		lblTel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblTel.setBounds(10, 126, 124, 36);
		panel.add(lblTel);
		
		JLabel mail = new JLabel("Mail            :");
		mail.setFont(new Font("Arial Black", Font.PLAIN, 12));
		mail.setBounds(10, 182, 124, 36);
		panel.add(mail);
		
		JLabel lblNewLabel_1 = new JLabel("Adresse    :");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 233, 124, 36);
		panel.add(lblNewLabel_1);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(162, 30, 178, 22);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
	
		
		textField_prenom = new JTextField();
		textField_prenom.setBounds(162, 77, 178, 22);
		panel.add(textField_prenom);
		textField_prenom.setColumns(10);
		
		textField_tel = new JTextField();
		textField_tel.setBounds(162, 134, 178, 22);
		panel.add(textField_tel);
		textField_tel.setColumns(10);
		
		textField_mail = new JTextField();
		textField_mail.setBounds(162, 190, 178, 22);
		panel.add(textField_mail);
		textField_mail.setColumns(10);
		
		textField_adresse = new JTextField();
		textField_adresse.setBounds(162, 241, 178, 22);
		panel.add(textField_adresse);
		textField_adresse.setColumns(10);
		
		JLabel lblDate = new JLabel("Date   :");
		lblDate.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDate.setBounds(10, 280, 124, 29);
		panel.add(lblDate);
		
		textField_date = new JTextField();
		textField_date.setBounds(162, 285, 178, 20);
		panel.add(textField_date);
		textField_date.setColumns(10);
		
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM stagiaire  ");){
				resultset.last();
					
					rs = resultset.getInt("MATRICULESTAGIAIRE");
				
				
			}
			
			catch(SQLException sqle){
				sqle.printStackTrace();
			}
		
		JButton btnValider = new JButton("Valider");
		btnValider.setBackground(SystemColor.activeCaption);
		btnValider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean bool;
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				matricule = rs+1;
				String nom = textField_nom.getText();
				String prenom = textField_prenom.getText(); 
				String tel = textField_tel.getText();
				String mail = textField_mail.getText();
				String adresse = textField_adresse.getText();
				
				java.sql.PreparedStatement insert =  connection.prepareStatement("INSERT INTO `mfc`.`stagiaire` "
				 		+ "(`MATRICULESTAGIAIRE`, `NOMSTAGIAIRE`, `PRENOMSTAGIAIRE`, `TELSTAGIAIRE`, `MAILSTAGIAIRE`, `ADRESSE`) "
				 		+ "VALUES ('"+matricule+"', '"+nom+"', '"+prenom+"', '"+tel+"', '"+mail+"', '"+adresse+"');");
					insert.executeUpdate();
					bool = true;
					
					insert.close();
					
					int numInscrit = Null;
					String date= textField_date.getText();
					java.sql.PreparedStatement insert2 = connection.prepareStatement("INSERT INTO `mfc`.`inscription`"
							+ " ( NUMINSCRIPTION, MATRICULESTAGIAIRE, DATEINSCRIPTION)"
							+ " VALUES('"+numInscrit+"','"+matricule+"','"+date+"')");
					insert2.executeUpdate();
					insert2.close();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					bool=false;
				}
				
				if (bool == true){
					JOptionPane.showMessageDialog(contentPane, "Les donn�es ont �t� bien enregistr�");
					setVisible(false);
					}
				else{
					JOptionPane.showMessageDialog(contentPane, "Les donn�es n'ont pas pu etre enregistr�es \n"
							+ " Veillez verifier que les donn�es sont correctes et R��ssayer � nouveau ");
				}
				
				
				
			}
		});
		btnValider.setBounds(69, 408, 89, 23);
		contentPane.add(btnValider);
		
		
		JButton btnAnnuller = new JButton("Annuler");
		btnAnnuller.setBackground(SystemColor.activeCaption);
		btnAnnuller.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		btnAnnuller.setBounds(268, 408, 89, 23);
		contentPane.add(btnAnnuller);
		
		JLabel lblAaaammjj = new JLabel("AAAA-MM-JJ");
		lblAaaammjj.setBounds(383, 355, 68, 14);
		contentPane.add(lblAaaammjj);
	}
}
