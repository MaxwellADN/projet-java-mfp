package Menu;
import java.sql.Connection;
import java.sql.DriverManager;


public class Connexion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Les �lements du protocol JDBC : mysql subprotocol; localhost est l'adresse duis the address 
  		// serveur o� est install�e la DB (serveur local) et 3306 est le port pour se connecter � la DB
  		String url = "jdbc:mysql://127.0.0.1:3306/";
  		// Connexion � la base de donn�es Books
		String database = "mfc";
		// Connexion avec login "root" et mot de passe "ADMIN" 
	  	String userName = "root"; 
	  	String password = "";
	  	/* L'objet connexion est obtenue avec la m�thode DriverManager.getConnection()
	  	  */
	  	 
	  	try (Connection connection = DriverManager.getConnection
	  		(url + database, userName, password)){
	  		System.out.println("Connexion � la Base de donn�es: R�ussie !!!");
	  	} catch (Exception e) {
	  		System.out.println("Connexion � la Base de donn�es: Impossible !!!");
		  	e.printStackTrace();
	  	}

	}

}
