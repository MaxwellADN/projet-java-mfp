package Menu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.SystemColor;

public class AjoutFormation extends JFrame {

	private JPanel contentPane;
	private JTextField textField_nom;
	private JTextField textField_code;
	private JTextField textField_Ddebut;
	private JTextField textField_Dfin;
	private JTextField textField_duree;
	private JTextField textField_prix;
	private PreparedStatement pst = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AjoutFormation frame = new AjoutFormation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AjoutFormation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 497, 461);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNouvelleFormation = new JLabel("Nouvelle Formation");
		lblNouvelleFormation.setFont(new Font("Arial Black", Font.BOLD, 14));
		lblNouvelleFormation.setBounds(31, 28, 186, 36);
		contentPane.add(lblNouvelleFormation);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel.setBounds(31, 65, 350, 305);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblCodeFormation = new JLabel("Code Formation   :");
		lblCodeFormation.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblCodeFormation.setBounds(10, 28, 124, 36);
		panel.add(lblCodeFormation);
		
		JLabel lblNomFormation = new JLabel("Nom Formation   :");
		lblNomFormation.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNomFormation.setBounds(10, 75, 124, 36);
		panel.add(lblNomFormation);
		
		JLabel lblNewLabel = new JLabel("Date debut          :");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 122, 124, 36);
		panel.add(lblNewLabel);
		
		JLabel lblDateFin = new JLabel("Date fin               :");
		lblDateFin.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDateFin.setBounds(10, 169, 124, 36);
		panel.add(lblDateFin);
		
		JLabel lblDure = new JLabel("Dur\u00E9e                  :");
		lblDure.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDure.setBounds(10, 216, 124, 36);
		panel.add(lblDure);
		
		JLabel lblNewLabel_1 = new JLabel("Prix Formation    :");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(10, 263, 124, 36);
		panel.add(lblNewLabel_1);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(162, 83, 178, 22);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
		textField_code = new JTextField();
		textField_code.setBounds(162, 36, 178, 22);
		panel.add(textField_code);
		textField_code.setColumns(10);
		
		textField_Ddebut = new JTextField();
		textField_Ddebut.setBounds(162, 130, 178, 22);
		panel.add(textField_Ddebut);
		textField_Ddebut.setColumns(10);
		
		textField_Dfin = new JTextField();
		textField_Dfin.setBounds(162, 177, 178, 22);
		panel.add(textField_Dfin);
		textField_Dfin.setColumns(10);
		
		textField_duree = new JTextField();
		textField_duree.setBounds(162, 224, 178, 22);
		panel.add(textField_duree);
		textField_duree.setColumns(10);
		
		textField_prix = new JTextField();
		textField_prix.setBounds(162, 271, 178, 22);
		panel.add(textField_prix);
		textField_prix.setColumns(10);
		
		JButton btnValider = new JButton("Valider");
		btnValider.setBackground(SystemColor.activeCaption);
		btnValider.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean bool = false;
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					
					String code= textField_code.getText();
					String nom= textField_nom.getText();
					String DateDebut= textField_Ddebut.getText();
					String DateFin= textField_Dfin.getText();
					String duree= textField_duree.getText();
					String prix= textField_prix.getText();
					java.sql.PreparedStatement prepare =  connection.prepareStatement("INSERT INTO `mfc`.`formation` "
						 		+ "(`CODEFORMATION`, `NOMFORMATION`, `DATEDEBUTFORMATION`, `DATEFINFORMATION`, `DUREE`, `PRIXFORMATION`) "
						 		+ "VALUES ('"+code+"', '"+nom+"', '"+DateDebut+"', '"+DateFin+"', '"+duree+"', '"+prix+"');");
					prepare.executeUpdate();
					bool = true;
										 
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				if (bool ==true){
					JOptionPane.showMessageDialog(contentPane, "Les donn�es ont �t� bien enregistr�");
					setVisible(false);
					}
				else{
					JOptionPane.showMessageDialog(contentPane, "Les donn�es n'ont pas pu etre enregistr�es \n"
							+ " Veillez verifier que les donn�es sont correctes et R��ssayer � nouveau ");
				}
				
						
			}
		});
		btnValider.setBounds(70, 388, 89, 23);
		contentPane.add(btnValider);
		
		JButton btnAnnuller = new JButton("Annuler");
		btnAnnuller.setBackground(SystemColor.activeCaption);
		btnAnnuller.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		btnAnnuller.setBounds(268, 388, 89, 23);
		contentPane.add(btnAnnuller);
		
		JLabel lblAaaammjj = new JLabel("AAAA-MM-JJ");
		lblAaaammjj.setBounds(391, 198, 90, 14);
		contentPane.add(lblAaaammjj);
		
		JLabel label = new JLabel("AAAA-MM-JJ");
		label.setBounds(391, 245, 90, 14);
		contentPane.add(label);
	}
}
