package Menu;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.text.MaskFormatter;

import com.mysql.jdbc.ResultSetRow;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.SystemColor;
import java.awt.Checkbox;

import javax.swing.JTextField;






public class SessionFormation extends JFrame {

	
	protected static final int Null = 0;
	private String CodeFormation;
	private int CodeNiveau;
	private int idSalle = 0;
	private JPanel contentPane;
	private int session = 0;
	private JTextField textField_date;
	
		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SessionFormation frame = new SessionFormation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SessionFormation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 90, 676, 612);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setLayout(null);
		
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(230, 230, 250));
		panel.setBorder(new LineBorder(SystemColor.activeCaption));
		panel.setBounds(161, 29, 364, 46);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SESSION FORMATION");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblNewLabel.setBounds(67, 11, 225, 24);
		lblNewLabel.setBorder(null);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Num Session");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1.setBounds(87, 140, 153, 34);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Date Session");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_2.setBounds(87, 312, 153, 46);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Formation");
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_3.setBounds(87, 198, 153, 46);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Niveau Formation");
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_4.setBounds(87, 255, 153, 46);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Nom Formateur");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_5.setBounds(87, 369, 153, 46);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Salle");
		lblNewLabel_6.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_6.setBounds(87, 426, 153, 46);
		contentPane.add(lblNewLabel_6);
		
		try{
			MaskFormatter date = new MaskFormatter("####--##--##");
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(250, 263, 232, 32);
		contentPane.add(comboBox_1);
	
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM niveauformation");
				){
					while(resultset.next())
					{
						comboBox_1.addItem(resultset.getString("DESCRIPTIF"));
					}
					resultset.close();
					}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		
			
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(249, 205, 356, 34);
		contentPane.add(comboBox);
		
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM formation");
				){
				while(resultset.next()){	 				
					comboBox.addItem(resultset.getString("NOMFORMATION"));		
					}
			
			resultset.close();
					}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(250, 434, 228, 32);
		contentPane.add(comboBox_3);
		
		
		
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM salle");
				){
					while(resultset.next())
					{
						comboBox_3.addItem(resultset.getString("nomSalle"));
					}
					}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}

		
		JButton btnEnregister = new JButton("Enregister");// actions sur bouton enregistrer
		btnEnregister.setBackground(SystemColor.activeCaption);
		btnEnregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//----------------------------------------------------------------------------------------------------------------------------
				// recup�ration du CodeFormation 
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultset = state.executeQuery("SELECT * FROM `formation` WHERE `NOMFORMATION`='"+comboBox.getSelectedItem()+"'");
						){
							while(resultset.next()){
							 CodeFormation = resultset.getString("CODEFORMATION");
							}
							
							resultset.close();
							
							}
				catch(SQLException sqle){
					sqle.printStackTrace();
				}
				//------------------------------------------------------------------------------------------------------------------------------
				// recuperaion du CodeNiveau
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultsetNiveau = state.executeQuery("SELECT * FROM `niveauformation` WHERE `DESCRIPTIF`='"+comboBox_1.getSelectedItem()+"'");
						){
							while(resultsetNiveau.next()){
							CodeNiveau = resultsetNiveau.getInt("CODENIVEAU");
							
							}
							
							resultsetNiveau.close();
							
							}
				catch(SQLException sqle){
					sqle.printStackTrace();
				}
				
				//---------------------------------------------------------------------------------------------------------------------------------
				// recuperation de l'IdSalle
				
				try(Connection connection = DbConnector.connectDB();
						Statement state= connection.createStatement();
						ResultSet resultsetSalle = state.executeQuery("SELECT * FROM `salle` WHERE `nomSalle`='"+comboBox_3.getSelectedItem()+"'");
						){
							while(resultsetSalle.next()){
							 idSalle = resultsetSalle.getInt("idSalle");
							}
							
							resultsetSalle.close();
							
							}
				catch(SQLException sqle){
					sqle.printStackTrace();
				}
				
				//----------------------------------------------------------------------------------------------------------------------------------
				// insertion de CodeFormation et IdSalle
				
				boolean bool = false;
				try {
					Connection connection = DbConnector.connectDB();
					Statement state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					
					int  codeSession = Null;
					String date = textField_date.getText();
					int codePlan=1;
					java.sql.PreparedStatement insert =  connection.prepareStatement("INSERT INTO mfc.sessionformation "
							+ "(CODESESSION,CODEFORMATION,CODEPLANNING,idSalle, DATESESSION)"
							+ "VALUES('"+codeSession+"','"+CodeFormation+"','"+codePlan+"','"+idSalle+"','"+date+"')");
						insert.executeUpdate();
						insert.close();
						bool = true;
										 
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				}
				
				if (bool == true){
					JOptionPane.showMessageDialog(contentPane, "Les donn�es ont �t� bien enregistr�");
					setVisible(false);
					}
				else{
					JOptionPane.showMessageDialog(contentPane, "Les donn�es n'ont pas pu etre enregistr�es \n"
							+ " Veillez verifier que les donn�es sont correctes et R��ssayer � nouveau ");
				}
			
				
				
			}
		});
		btnEnregister.setBounds(87, 504, 124, 34);
		contentPane.add(btnEnregister);
		
		JButton btnNewButton = new JButton("Annuler");
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FenMenuPrincipal fenetre = new FenMenuPrincipal();
				fenetre.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setBounds(250, 504, 109, 34);
		contentPane.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(250, 142, 109, 32);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setFont(new Font("Arial Black", Font.BOLD, 14));
		panel_1.add(lblNewLabel_7);
		
		
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM sessionformation");
				){
					resultset.last();
					int idsession= resultset.getInt("CODESESSION");
					int session = idsession +1;
					lblNewLabel_7.setText(""+session);							
					}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		
		JLabel lblDateformatJjmmaaaa = new JLabel("DateFormat: AAAA--MM--JJ");
		lblDateformatJjmmaaaa.setBounds(492, 325, 158, 22);
		contentPane.add(lblDateformatJjmmaaaa);
		
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(250, 377, 228, 32);
		contentPane.add(comboBox_2);
		
		textField_date = new JTextField();
		textField_date.setBounds(250, 320, 233, 32);
		contentPane.add(textField_date);
		textField_date.setColumns(10);
		
				
		try(Connection connection = DbConnector.connectDB();
				Statement state= connection.createStatement();
				ResultSet resultset = state.executeQuery("SELECT * FROM consultant");
				){
					while(resultset.next())
					{
						comboBox_2.addItem(resultset.getString("NomFormateur")+"  "+resultset.getString("prenomFormateur"));
					}
					}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		

		
		
	}
}
